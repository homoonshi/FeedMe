package com.todoslave.feedme.DTO;

import lombok.Data;

@Data
public class TodoCategoryResponseDTO {

  private int id;
  private String name;

}
