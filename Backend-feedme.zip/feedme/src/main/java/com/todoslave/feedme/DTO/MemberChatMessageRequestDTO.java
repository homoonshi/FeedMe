//맴버 채팅 주석

//package com.todoslave.feedme.DTO;
//
//import lombok.Getter;
//
//@Getter
//public class ChatMessageRequestDTO {
//
//  private String message;
//
//}
