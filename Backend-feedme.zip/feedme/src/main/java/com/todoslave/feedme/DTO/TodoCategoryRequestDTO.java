package com.todoslave.feedme.DTO;

import lombok.Getter;

@Getter
public class TodoCategoryRequestDTO {

  private int id;
  private String name;

}
