package com.todoslave.feedme.DTO;

import lombok.Getter;

@Getter
public class AlarmCheckRequestDTO {

  private String checkTime;

}
