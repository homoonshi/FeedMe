package com.todoslave.feedme.DTO;

public class MemberSearchRequestDTO {

    // STring 이라서 굳이 안쓸듯

}
