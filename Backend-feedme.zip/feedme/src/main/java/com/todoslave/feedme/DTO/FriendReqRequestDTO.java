package com.todoslave.feedme.DTO;

import lombok.Getter;

@Getter
public class FriendReqRequestDTO {

  // 상대방 닉네임
  private String counterpartNickname;

}
