package com.todoslave.feedme.DTO;

import lombok.Getter;

@Getter
public class TodoModifyRequestDTO {

  private int id;
  private String content;

}
