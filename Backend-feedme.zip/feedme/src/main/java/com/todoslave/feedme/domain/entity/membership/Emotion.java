package com.todoslave.feedme.domain.entity.membership;

public enum Emotion {
    BASIC, JOY, SAD
}
