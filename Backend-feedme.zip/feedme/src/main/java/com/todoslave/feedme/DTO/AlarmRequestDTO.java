package com.todoslave.feedme.DTO;

import lombok.Getter;

@Getter
public class AlarmRequestDTO {

    private String token;
    private String message;

}
