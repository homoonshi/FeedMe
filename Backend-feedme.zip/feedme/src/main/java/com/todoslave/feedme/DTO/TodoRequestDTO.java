package com.todoslave.feedme.DTO;

import java.time.LocalDate;
import lombok.Getter;

@Getter
public class TodoRequestDTO {

  private LocalDate date;

}
