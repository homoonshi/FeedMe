package com.todoslave.feedme;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Hello {

    private String data;

}
