package com.todoslave.feedme.service;

public interface FeedService {

}
