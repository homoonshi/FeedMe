package com.todoslave.feedme.DTO;

import lombok.Data;

@Data
public class CreatureMakeRequestDTO {

    String creatureName;

    String keyword;

//    MultipartFile photo;
    String photo;
}
