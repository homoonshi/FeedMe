적용하고 싶은 css파일에서 아래와 같이 입력
@font-face {
  font-family: "GmarketSansTTFMedium";
  src: url("./assets/font/GmarketSansTTFMedium.ttf"); // 내가 저장한 경로!
}