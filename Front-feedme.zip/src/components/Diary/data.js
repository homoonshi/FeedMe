const data = [
    {
      id: 1,
      img: "img-cat.png",
      thumbnail: "img-cat.png",
      date: "08.01",
      content: "오늘은 운동을 하고 코딩 공부를 했다. 그리고 친구를 만났다."
    },
    {
      id: 2,
      img: "thumbnail1.png",
      thumbnail: "thumbnail1.png",
      date: "08.02",
      content: "오늘은 점심을 먹고 코딩 공부를 했다."
    },
    {
      id: 3,
      img: "thumbnail2.jpg",
      thumbnail: "thumbnail2.jpg",
      date: "08.03",
      content: "오늘은 친구를 만났다."
    },
    {
      id: 4,
      img: "thumbnail3.png",
      thumbnail: "thumbnail3.png",
      date: "08.04",
      content: "오늘은 집에서 강아지와 놀았다."
    }
  ];
  
  export default data;