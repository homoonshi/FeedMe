import React from 'react';

const ChatCreature = () => {
  return (
    <div>
      <h2>Chat with creature</h2>
    </div>
  );
};

export default ChatCreature;
