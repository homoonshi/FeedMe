import React from 'react';

const ChatWindow = ({ friend }) => {
  return (
    <div>
      <h2>Chat with {friend.name}</h2>
    </div>
  );
};

export default ChatWindow;
